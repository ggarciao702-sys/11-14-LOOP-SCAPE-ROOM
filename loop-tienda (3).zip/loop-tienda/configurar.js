'use strict';
// Asistente de configuración: te hace 3 preguntas y crea el archivo .env.
// Se ejecuta solo la primera vez (INICIAR.bat / iniciar.sh) o a mano con:  node configurar.js
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const readline = require('node:readline');

const destino = path.join(__dirname, '.env');
const rl = readline.createInterface({ input: process.stdin, terminal: false });
const lineas = rl[Symbol.asyncIterator]();
// Muestra la pregunta y espera la siguiente línea escrita (si no hay más, usa el valor por defecto)
const preguntar = async (texto, def = '') => {
  process.stdout.write(texto);
  const { value, done } = await lineas.next();
  return ((done ? '' : value) || '').trim() || def;
};

(async () => {
  console.log('\n=== Configuración de LOOP (se hace una sola vez) ===\n');
  if (fs.existsSync(destino)) {
    if ((await preguntar('Ya existe un archivo .env. ¿Reemplazarlo? (s/N): ')).toLowerCase() !== 's') { rl.close(); return console.log('No se cambió nada.'); }
  }

  console.log('1) Contraseña del panel de datos (la que pedirá al tocar el logo del inicio).');
  console.log('   Mínimo 8 caracteres. Si solo presionas Enter, se crea una segura.');
  let clave = await preguntar('   Contraseña: ');
  while (clave && clave.length < 8) clave = await preguntar('   Muy corta, escribe una de 8 o más (o Enter para crear una): ');
  const generada = !clave;
  if (generada) clave = crypto.randomBytes(9).toString('base64url');

  console.log('\n2) Correo donde quieres recibir los datos de cada pedido y mensaje.');
  const destinoCorreo = await preguntar('   Correo [ggarciao702@inemkennedy.edu.co]: ', 'ggarciao702@inemkennedy.edu.co');

  console.log('\n3) Cuenta desde la que se ENVÍAN esos correos (por ejemplo un Gmail tuyo).');
  console.log('   En Gmail necesitas una "contraseña de aplicación": https://myaccount.google.com/apppasswords');
  console.log('   Puedes dejarlo vacío (Enter): los datos igual se guardan y los verás en el panel.');
  const smtpUser = await preguntar('   Gmail que envía: ');
  const smtpPass = smtpUser ? await preguntar('   Contraseña de aplicación: ') : '';

  fs.writeFileSync(destino, [
    '# Creado por configurar.js. No lo subas a internet ni lo compartas.',
    'PORT=3000',
    `MAIL_TO=${destinoCorreo}`,
    'SMTP_HOST=smtp.gmail.com', 'SMTP_PORT=465', 'SMTP_SECURE=true',
    `SMTP_USER=${smtpUser}`, `SMTP_PASS=${smtpPass.replace(/\s+/g, '')}`,
    `ADMIN_PASSWORD=${clave}`, 'DB_FILE=loop.db', '',
  ].join('\n'), 'utf8');

  console.log('\n✔ Listo, se creó el archivo .env');
  console.log(`   Contraseña del panel: ${clave}${generada ? '   <-- anótala, la creamos por ti' : ''}\n`);
  rl.close();
})();
